
GET_SAMPLE_LIST_TOPIC = 'get_sample_list'
TAKE_SAMPLE_TOPIC = 'take_sample'
REMOVE_SAMPLE_TOPIC = 'remove_sample'
COMPUTE_CALIBRATION_TOPIC = 'compute_calibration'
SAVE_CALIBRATION_TOPIC = 'save_calibration'
